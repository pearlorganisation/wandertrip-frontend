import { useState } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { useToast } from '@/hooks/use-toast';
import { 
  User, MapPin, Calendar, Bookmark, Clock, Settings, LogOut,
  Edit, Camera, Shield, Globe, CreditCard, Plane, Hotel, Car
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import TravelStats from '@/components/TravelStats';
import SavedDestinations from '@/components/SavedDestinations';
import TravelTimeline from '@/components/TravelTimeline';

const mockUserData = {
  name: "Rahul Sharma",
  email: "rahul.sharma@example.com",
  profileImage: "https://images.unsplash.com/photo-1607081692251-d689f1b9af84?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cG9ydHJhaXR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=800&q=60",
  location: "123 Ashok Road, Jaipur, India",
  memberSince: "June 2023",
  travelPreferences: [
    "Adventure", "Cultural", "Photography", "Food & Dining", "Hiking"
  ],
  stats: {
    tripsCompleted: 8,
    countriesVisited: 12,
    citiesExplored: 24,
    totalDistance: 45720,
    travelPoints: 3450,
    travelRank: "Explorer"
  },
  upcomingTrips: [
    {
      id: "trip-123",
      destination: "Bali, Indonesia",
      dates: "Jun 15 - Jun 22, 2024",
      image: "https://images.unsplash.com/photo-1537996194471-e657df975ab4",
      status: "Confirmed"
    }
  ],
  pastTrips: [
    {
      id: "trip-456",
      destination: "Paris, France",
      dates: "Mar 10 - Mar 17, 2024",
      image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34",
      status: "Completed"
    },
    {
      id: "trip-789",
      destination: "Kyoto, Japan",
      dates: "Nov 5 - Nov 15, 2023",
      image: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e",
      status: "Completed"
    }
  ],
  savedDestinations: [
    {
      id: "dest-123",
      name: "Santorini",
      location: "Greece",
      image: "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff",
      saved: true
    },
    {
      id: "dest-456",
      name: "Machu Picchu",
      location: "Peru",
      image: "https://images.unsplash.com/photo-1526392060635-9d6019884377",
      saved: true
    },
    {
      id: "dest-789",
      name: "Amalfi Coast",
      location: "Italy",
      image: "https://images.unsplash.com/photo-1612698093158-e07ac200d44e",
      saved: true
    }
  ],
  rewards: {
    tier: "Gold",
    points: 3450,
    nextTier: 5000,
    badges: [
      { name: "Globetrotter", icon: "🌍", achieved: true },
      { name: "Culture Explorer", icon: "🏛️", achieved: true },
      { name: "Mountain Climber", icon: "🏔️", achieved: true },
      { name: "Beach Lover", icon: "🏝️", achieved: false }
    ]
  }
};

const Profile = () => {
  const { toast } = useToast();
  const [userData, setUserData] = useState(mockUserData);
  const [activeTab, setActiveTab] = useState("overview");
  const [editMode, setEditMode] = useState(false);
  
  const handleUpdateProfile = () => {
    setEditMode(false);
    toast({
      title: "Profile Updated",
      description: "Your profile information has been updated successfully.",
    });
  };
  
  const handleLogout = () => {
    toast({
      title: "Logged Out",
      description: "You have been logged out successfully.",
    });
    // In a real app, this would redirect to login page
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-24">
        <section className="py-6 bg-secondary/30">
          <div className="container px-4 sm:px-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4">
              <div className="flex items-center mb-4 sm:mb-0">
                <h1 className="text-2xl md:text-3xl font-medium tracking-tight">
                  My Profile
                </h1>
              </div>
              
              <div className="flex space-x-3">
                <Link to="/settings">
                  <Button variant="outline" size="sm">
                    <Settings size={16} className="mr-2" />
                    Settings
                  </Button>
                </Link>
                <Button variant="outline" size="sm" onClick={handleLogout}>
                  <LogOut size={16} className="mr-2" />
                  Logout
                </Button>
              </div>
            </div>
          </div>
        </section>
        
        <section className="py-8">
          <div className="container px-4 sm:px-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              <div className="lg:col-span-4">
                <div className="glass rounded-xl p-6 mb-6">
                  <div className="flex flex-col items-center text-center mb-6">
                    <div className="relative mb-4">
                      <Avatar className="w-24 h-24 border-4 border-background">
                        <AvatarImage src={userData.profileImage} alt={userData.name} />
                        <AvatarFallback>{userData.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <Dialog>
                        <DialogTrigger asChild>
                          <button className="absolute bottom-0 right-0 bg-primary text-primary-foreground p-1.5 rounded-full">
                            <Camera size={16} />
                          </button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Update Profile Picture</DialogTitle>
                            <DialogDescription>
                              Upload a new profile picture or choose from your gallery.
                            </DialogDescription>
                          </DialogHeader>
                          <div className="grid gap-4 py-4">
                            <Button>Upload Photo</Button>
                            <Button variant="outline">Choose from Library</Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                    
                    <h2 className="text-xl font-medium">{userData.name}</h2>
                    <div className="flex items-center text-sm text-muted-foreground mt-1">
                      <MapPin size={14} className="mr-1" />
                      {userData.location}
                    </div>
                    
                    <div className="flex items-center mt-2">
                      <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                        {userData.rewards.tier} Member
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between items-center mb-1.5 text-sm">
                        <span>Reward Points: {userData.rewards.points}</span>
                        <span>{userData.rewards.nextTier - userData.rewards.points} until {userData.rewards.tier === "Gold" ? "Platinum" : "Diamond"}</span>
                      </div>
                      <Progress value={(userData.rewards.points / userData.rewards.nextTier) * 100} className="h-2" />
                    </div>
                    
                    <div className="pt-4 border-t border-border">
                      <h3 className="text-sm font-medium mb-3">Travel Preferences</h3>
                      <div className="flex flex-wrap gap-2">
                        {userData.travelPreferences.map((pref, index) => (
                          <Badge key={index} variant="secondary" className="py-1">
                            {pref}
                          </Badge>
                        ))}
                        <Dialog>
                          <DialogTrigger asChild>
                            <Badge variant="outline" className="py-1 cursor-pointer">
                              <Edit size={12} className="mr-1" /> Edit
                            </Badge>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Edit Travel Preferences</DialogTitle>
                              <DialogDescription>
                                Select your preferred travel styles and interests.
                              </DialogDescription>
                            </DialogHeader>
                            <div className="grid gap-4 py-4">
                              <Button onClick={() => {
                                toast({
                                  title: "Preferences Updated",
                                  description: "Your travel preferences have been updated.",
                                });
                              }}>Save Preferences</Button>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </div>
                    
                    <div className="pt-4 border-t border-border">
                      <h3 className="text-sm font-medium mb-3">Account Info</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-start">
                          <User size={16} className="mr-2 mt-0.5 text-muted-foreground" />
                          <div>
                            <p className="text-muted-foreground">Email</p>
                            <p>{userData.email}</p>
                          </div>
                        </div>
                        <div className="flex items-start">
                          <Calendar size={16} className="mr-2 mt-0.5 text-muted-foreground" />
                          <div>
                            <p className="text-muted-foreground">Member Since</p>
                            <p>{userData.memberSince}</p>
                          </div>
                        </div>
                        <div className="flex items-start">
                          <Shield size={16} className="mr-2 mt-0.5 text-muted-foreground" />
                          <div>
                            <p className="text-muted-foreground">Account Security</p>
                            <Link to="/settings" className="text-primary hover:underline">
                              Manage Settings
                            </Link>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="pt-4 border-t border-border">
                      <h3 className="text-sm font-medium mb-3">Travel Badges</h3>
                      <div className="grid grid-cols-4 gap-2">
                        {userData.rewards.badges.map((badge, index) => (
                          <div 
                            key={index} 
                            className={`p-2 rounded-lg text-center ${!badge.achieved ? 'opacity-40' : ''}`}
                          >
                            <div className="text-2xl mb-1">{badge.icon}</div>
                            <p className="text-xs">{badge.name}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="lg:col-span-8">
                <Tabs 
                  defaultValue="overview" 
                  value={activeTab}
                  onValueChange={setActiveTab}
                  className="w-full"
                >
                  <TabsList className="w-full justify-start mb-6 bg-secondary/50 p-1">
                    <TabsTrigger value="overview" className="flex-1 md:flex-none">Overview</TabsTrigger>
                    <TabsTrigger value="trips" className="flex-1 md:flex-none">My Trips</TabsTrigger>
                    <TabsTrigger value="saved" className="flex-1 md:flex-none">Saved</TabsTrigger>
                    <TabsTrigger value="memories" className="flex-1 md:flex-none">Memories</TabsTrigger>
                    <TabsTrigger value="rewards" className="flex-1 md:flex-none">Rewards</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="overview" className="space-y-6">
                    <div>
                      <TravelStats stats={userData.stats} />
                    </div>
                    
                    <div className="glass rounded-xl p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-medium">Upcoming Trip</h3>
                        <Link to="/trip-planner" className="text-sm text-primary hover:underline">
                          Plan New Trip
                        </Link>
                      </div>
                      
                      {userData.upcomingTrips.length > 0 ? (
                        <div className="bg-secondary/30 rounded-xl p-4">
                          <div className="flex items-start">
                            <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0 mr-4">
                              <img 
                                src={userData.upcomingTrips[0].image} 
                                alt={userData.upcomingTrips[0].destination}
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="flex-grow">
                              <h4 className="font-medium">{userData.upcomingTrips[0].destination}</h4>
                              <div className="flex items-center text-sm text-muted-foreground mt-1 mb-2">
                                <Calendar size={14} className="mr-1" />
                                {userData.upcomingTrips[0].dates}
                              </div>
                              <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-200">
                                {userData.upcomingTrips[0].status}
                              </Badge>
                            </div>
                            <div className="flex-shrink-0">
                              <Link to={`/itinerary/${userData.upcomingTrips[0].id}`}>
                                <Button variant="outline" size="sm">View Details</Button>
                              </Link>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-3 gap-3 mt-4">
                            <Link to="/booking" className="p-3 bg-background rounded-lg text-center">
                              <Plane size={18} className="mx-auto mb-1" />
                              <span className="text-xs font-medium">Flight Status</span>
                            </Link>
                            <Link to="/booking" className="p-3 bg-background rounded-lg text-center">
                              <Hotel size={18} className="mx-auto mb-1" />
                              <span className="text-xs font-medium">Hotel Details</span>
                            </Link>
                            <Link to="/booking" className="p-3 bg-background rounded-lg text-center">
                              <Car size={18} className="mx-auto mb-1" />
                              <span className="text-xs font-medium">Transportation</span>
                            </Link>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <p className="text-muted-foreground mb-4">You don't have any upcoming trips.</p>
                          <Link to="/trip-planner">
                            <Button>Plan Your Next Adventure</Button>
                          </Link>
                        </div>
                      )}
                    </div>
                    
                    <div className="glass rounded-xl p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-medium">Recently Viewed Destinations</h3>
                        <Link to="/destinations" className="text-sm text-primary hover:underline">
                          View All
                        </Link>
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        {userData.savedDestinations.map((destination, index) => (
                          <div 
                            key={index}
                            className="rounded-lg overflow-hidden group relative"
                          >
                            <div className="aspect-video relative">
                              <img 
                                src={destination.image} 
                                alt={destination.name}
                                className="absolute inset-0 w-full h-full object-cover transition-transform group-hover:scale-105"
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                              <div className="absolute bottom-0 left-0 p-3">
                                <h4 className="text-white font-medium">{destination.name}</h4>
                                <p className="text-white/80 text-xs">{destination.location}</p>
                              </div>
                              <button 
                                className="absolute top-2 right-2 p-1.5 bg-white/20 backdrop-blur-sm rounded-full hover:bg-white/40 transition-colors"
                                onClick={() => {
                                  toast({
                                    title: `${destination.saved ? 'Removed from' : 'Added to'} Favorites`,
                                    description: `${destination.name} has been ${destination.saved ? 'removed from' : 'added to'} your saved destinations.`,
                                  });
                                }}
                              >
                                <Bookmark 
                                  size={16} 
                                  fill={destination.saved ? "white" : "none"}
                                  className="text-white" 
                                />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="trips" className="space-y-6">
                    <div className="glass rounded-xl p-6">
                      <h3 className="text-lg font-medium mb-4">Upcoming Trips</h3>
                      
                      {userData.upcomingTrips.length > 0 ? (
                        <div className="space-y-4">
                          {userData.upcomingTrips.map((trip, index) => (
                            <div key={index} className="flex items-start p-4 bg-secondary/30 rounded-lg">
                              <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0 mr-4">
                                <img 
                                  src={trip.image} 
                                  alt={trip.destination}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="flex-grow">
                                <h4 className="font-medium">{trip.destination}</h4>
                                <div className="flex items-center text-sm text-muted-foreground mt-1 mb-2">
                                  <Calendar size={14} className="mr-1" />
                                  {trip.dates}
                                </div>
                                <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-200">
                                  {trip.status}
                                </Badge>
                              </div>
                              <div className="flex-shrink-0">
                                <Link to={`/itinerary/${trip.id}`}>
                                  <Button variant="outline" size="sm">View Details</Button>
                                </Link>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <p className="text-muted-foreground mb-4">You don't have any upcoming trips.</p>
                          <Link to="/trip-planner">
                            <Button>Plan Your Next Adventure</Button>
                          </Link>
                        </div>
                      )}
                    </div>
                    
                    <div className="glass rounded-xl p-6">
                      <h3 className="text-lg font-medium mb-4">Past Trips</h3>
                      
                      {userData.pastTrips.length > 0 ? (
                        <div className="space-y-4">
                          {userData.pastTrips.map((trip, index) => (
                            <div key={index} className="flex items-start p-4 bg-secondary/30 rounded-lg">
                              <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0 mr-4">
                                <img 
                                  src={trip.image} 
                                  alt={trip.destination}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="flex-grow">
                                <h4 className="font-medium">{trip.destination}</h4>
                                <div className="flex items-center text-sm text-muted-foreground mt-1 mb-2">
                                  <Calendar size={14} className="mr-1" />
                                  {trip.dates}
                                </div>
                                <Badge variant="outline" className="bg-muted text-muted-foreground border-muted-foreground/20">
                                  {trip.status}
                                </Badge>
                              </div>
                              <div className="flex-shrink-0">
                                <Link to={`/itinerary/${trip.id}`}>
                                  <Button variant="outline" size="sm">View Details</Button>
                                </Link>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <p className="text-muted-foreground">You haven't taken any trips yet.</p>
                        </div>
                      )}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="saved" className="space-y-6">
                    <div>
                      <SavedDestinations savedDestinations={userData.savedDestinations} />
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="memories" className="space-y-6">
                    <div>
                      <TravelTimeline />
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="rewards" className="space-y-6">
                    <div className="glass rounded-xl p-6">
                      <div className="flex items-center justify-between mb-6">
                        <h3 className="text-lg font-medium">Reward Status</h3>
                        <Link to="/rewards" className="text-sm text-primary hover:underline">
                          View All Rewards
                        </Link>
                      </div>
                      
                      <div className="bg-secondary/30 rounded-xl p-6 text-center mb-6">
                        <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                          <span className="text-3xl">{userData.rewards.tier === "Gold" ? "🥇" : userData.rewards.tier === "Silver" ? "🥈" : "🥉"}</span>
                        </div>
                        <h4 className="text-xl font-medium mb-1">{userData.rewards.tier} Member</h4>
                        <p className="text-sm text-muted-foreground mb-4">
                          {userData.rewards.points} points earned
                        </p>
                        
                        <div className="space-y-3">
                          <div>
                            <div className="flex justify-between items-center mb-1.5 text-sm">
                              <span>Next Tier: {userData.rewards.tier === "Gold" ? "Platinum" : "Diamond"}</span>
                              <span>{userData.rewards.nextTier - userData.rewards.points} points to go</span>
                            </div>
                            <Progress value={(userData.rewards.points / userData.rewards.nextTier) * 100} className="h-2" />
                          </div>
                        </div>
                      </div>
                      
                      <h4 className="font-medium mb-3">Available Benefits</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {[
                          { title: "Airport Lounge Access", description: "Free access at select international airports", icon: "✈️" },
                          { title: "Priority Check-in", description: "Skip the lines at partner hotels", icon: "🏨" },
                          { title: "Exclusive Discounts", description: "Up to 15% off on luxury experiences", icon: "💎" },
                          { title: "Concierge Service", description: "24/7 travel assistance during your trips", icon: "🛎️" },
                        ].map((benefit, index) => (
                          <div key={index} className="flex p-4 rounded-lg bg-muted/50">
                            <div className="flex-shrink-0 mr-4 text-2xl">{benefit.icon}</div>
                            <div>
                              <h5 className="font-medium">{benefit.title}</h5>
                              <p className="text-sm text-muted-foreground">{benefit.description}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="glass rounded-xl p-6">
                      <h3 className="text-lg font-medium mb-4">Travel Achievements</h3>
                      
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                        {userData.rewards.badges.map((badge, index) => (
                          <div 
                            key={index} 
                            className={`p-4 rounded-lg bg-secondary/30 text-center ${!badge.achieved ? 'opacity-40' : ''}`}
                          >
                            <div className="text-3xl mb-2">{badge.icon}</div>
                            <h4 className="font-medium">{badge.name}</h4>
                            <p className="text-xs text-muted-foreground mt-1">
                              {badge.achieved ? "Achieved" : "In Progress"}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Profile;
