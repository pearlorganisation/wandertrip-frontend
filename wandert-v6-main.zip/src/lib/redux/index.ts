import { combineReducers } from "@reduxjs/toolkit";
import authReducer from "../redux/Slice/authSlice"
// import otpReducer from "./slice/otpVerificationSlice";

const rootReducer = combineReducers({
  auth: authReducer, // Add other reducers here
//   otp: otpReducer,
 
});

export type RootState = ReturnType<typeof rootReducer>; // Define RootState type
export default rootReducer;
